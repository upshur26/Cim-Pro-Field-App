CIM Team Field App - Fixed Full Version

Upload this entire ZIP to Netlify.

Includes:
- Fixed mobile layout
- Home
- Daily workflow
- Equipment / systems checklists
- Forms
- Quick Cards
- Reports
- Issue tracking
- Digital sign-off
- PWA manifest
- Service worker/offline cache

Do not upload only index.html. Upload the whole ZIP.
